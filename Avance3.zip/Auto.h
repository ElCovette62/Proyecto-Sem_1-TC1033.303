#include "Neumatico.h"
#include "Suelo.h"
#include "Combustible.h"

class Auto :
    public Neumatico, Combustible, Suelo
{
private:
    std::string range;

public:
    Auto(std::string tipoN, std::string tipoS, int cant);
    void setRange(const std::string range) const;
    std::string getInfoAuto() const;
};



