#include "Auto.h"
#include <sstream>



Auto::Auto(std::string tipoN, std::string tipoS, int cant) :Neumatico(tipoN), Suelo(tipoS), Combustible(cant)
{
}

void Auto::setRange(const std::string range) const
{
}

std::string Auto::getInfoAuto() const {
    std::ostringstream stream;
    stream << "Información del Auto:\n";
    stream << "Neumático: " << neumatico.getInfoNeumatico() << "\n";
    stream << "Suelo: " << suelo.getInfoSuelo() << "\n";
    stream << "Combustible: " << combustible.getInfoCombustible();
    return stream.str();
}
