#include "Neumatico.h"
#include "Suelo.h"
#include "Combustible.h"

int main()
{
/**
Neumatico N1("Hard", 22.5);
Neumatico N2("Medium", 35.5);
Neumatico N3("Soft", 39.00);

Suelo S1("Avanzado", 3);
Suelo S2("Balanceado", 2);
Suelo S3("Basico", 1);

Combustible C1(60, "LLeno");
Combustible C2(45, "3/4");
Combustible C3(30, "Medio");
Combustible C4(15, "1/4");
**/
std::cout << N1.getInfoNeumatico() << std::endl;
std::cout << S1.getInfoSuelo() << std::endl;
std::cout << C1.getInfoCombustible() << std::endl;

return 0;

}
