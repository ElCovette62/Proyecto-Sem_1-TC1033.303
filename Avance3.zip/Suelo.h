#include <string>

class Suelo {
private:
    std::string tipoSuelo;
    int downforce;
    std::string downf;

public:
    Suelo(std::string tipos,int df);
    void setSuelo(const std::string tipoS, int downforce);
    std::string getInfoSuelo() const;
};


