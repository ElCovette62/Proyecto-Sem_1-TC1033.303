#include "Neumatico.h"

Neumatico::Neumatico(std::string tipoN, float temp)
    :
    tipoNeumatico(tipoN),
    temperatura(temp)
{

}

void Neumatico::setNeumatico(const std::string tipoN, float temp)
{

}

std::string Neumatico::getInfoNeumatico() const
{
    std::string tempe = std::to_string(temperatura);
	return "Tipo de Neumatico: " + tipoNeumatico + ", Temperatura: " + tempe + " Celcius";
}
