#include "Combustible.h"

Combustible::Combustible(float cant,std::string stat):cantidad(cant),status(stat)
{
}

void Combustible::setCombustible(float cantidadCombustible) 
{

}

void Combustible::setStatus(const std::string statusC) 
{

}

std::string Combustible::getInfoCombustible() const {
    
     return "Cantidad de Combustible: " + std::to_string(cantidad) + " L" + ", Estado: " + status;
}
