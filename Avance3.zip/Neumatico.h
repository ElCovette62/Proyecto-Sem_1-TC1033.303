#include <string>
#include <iostream>

class Neumatico
{
private:
	std::string tipoNeumatico;
	float temperatura;
	std::string tempS;
public:

	Neumatico(std::string tipoN, float temp);
	void setNeumatico(const std::string tipoN, float temp);
	std::string getInfoNeumatico() const;
};

