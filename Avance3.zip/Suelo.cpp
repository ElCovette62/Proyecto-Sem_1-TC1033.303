#include "Suelo.h"

Suelo::Suelo(std::string tipoS, int df) :tipoSuelo(tipoS), downforce(df)
{
}

void Suelo::setSuelo(const std::string tipoS, int downforceValue) 
{
    
}

std::string Suelo::getInfoSuelo() const {
    std::string downf = std::to_string(downforce);
    return "Tipo de Suelo: " + tipoSuelo + ", Downforce: " + downf;
}
